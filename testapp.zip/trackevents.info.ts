/**
 * Created by chaninsai on 9/8/2016.
 */
///<reference path="domain.info.ts"/>


namespace cominfo {

    export enum EObjectState {
        INVALID = 0x000,
        // 10-bit track object status : object movement states bit0:move, bit1:power, bit2:locate
        NOLO_Parking    = 0x200,
        NOLO_Moving     = 0x201,
        NOLO_Neutral    = 0x202,
        NOLO_Driving    = 0x203,
        LOCA_Parking    = 0x204,
        LOCA_Moving     = 0x205,
        LOGA_Neutral    = 0x206,
        LOCA_Driving    = 0x207,
    }

    export type  CauseUnitType = 'text' | 'base64' | 'binary' | 'second' | 'millisec' | 'voltage' | 'degree' | 'accelerate' | 'coordinate';

    export const enum ELocaSystem {
        GNSS,
        CELL,
        // WIFI,
        // BEACON,
        // IP
    }

    export interface IEventLocation {
        _locaSystem: ELocaSystem|number,
        _coordinate: number[],
        coverage: number,
        locaLevel: number
        locaId: number;
        locaNames: string[];
    }

    export class EventLocationStatic implements IEventLocation {

        _locaSystem: cominfo.ELocaSystem|number;
        _coordinate: number[];
        coverage: number;
        locaLevel: number;
        locaId: number;
        locaNames: string[];

        constructor(locateSystem: cominfo.ELocaSystem|number, coordinate: number[], coverage?: number, locateLevel?: number, locaId?: number, locateNames?: string[]) {

            this._locaSystem = (locateSystem) ? locateSystem : ELocaSystem.GNSS;
            this._coordinate = ((coordinate instanceof Array) && coordinate.length >= 2) ? cloneObject(coordinate, true) : null;
            this.coverage = (coverage) ? coverage : -1;
            this.locaLevel = (locateLevel) ? locateLevel : -1;
            this.locaId = (locaId) ? locaId : -1;
            this.locaNames = ((locateNames instanceof Array) && locateNames.length) ? cloneObject(locateNames, true) : null;
        }
    }

    export function convertGeoMin(geoMin: string): number {
        let dot = geoMin.indexOf('.');
        if (dot < 3) return 0.0;
        let pint: number = parseInt(geoMin.substr(0, dot - 2));
        let preal: number = parseFloat(geoMin.substr(dot - 2));
        return preal = (!isNaN(preal) && !isNaN(pint) ? preal / 60.0 + pint : NaN);
    }

    export interface IEventCause {
        itemno: number,
        name: string,
        unit: CauseUnitType|string,
        valueText: string
        valueNumber: number,
    }

    export class EventCauseStatic implements IEventCause {

        itemno: number;
        name: string;
        unit: cominfo.CauseUnitType|string;
        valueText: string;
        valueNumber: number;

        constructor(name: string, unit: CauseUnitType|string, value: number|string, itemno?: number, causeList?: IEventCause[]) {

            this.name = name;
            this.unit = unit;
            if (this.isUnitInText()) {
                this.valueText = (typeof value === 'string') ? <string> value : ((typeof value === 'number') ? value.toString() : null);
                this.valueNumber = (typeof value === 'number') ? <number>value : 0;
            }
            else {
                this.valueText = null;
                this.valueNumber = <number>value;
            }

            this.itemno = (typeof itemno === 'number') ? itemno : -1;
            if (causeList instanceof  Array) {
                this.itemno = (this.itemno === -1) ? causeList.length : this.itemno;
                causeList.splice(this.itemno, 1, this);
            }
        }

        isUnitInText(): boolean {

            return (this.unit === 'text' || this.unit === 'base64');
        }
    }

    export enum EEventType {
        ET_INVALID,
        ET_Device,
        ET_Vehicle,
        ET_Resource,
    }

    export interface IObjectEvent {
        // Event id. from (EventType << 8 | (DomainId (15-bit) >> 7) & 0xFF) * 2^40 + getTime() from 2012-01-01, in millisec. (40-bit)
        _id: number,

        _evenType: number|EEventType,
        // .. who ..
        _objId: number|IObjectInfo;
        // Domain id. 15-bit represent in Crockford's Base32
        _domaId: number|IDomainInfo,
        // .. what ..
        _evenCode: number,

        objState: number|EObjectState,
        // .. when ..
        _occurredAt: Date,

        realtime: boolean,
        // .. where ..
        _placeName: string,

        evenLocation: IEventLocation,
        // .. why ..
        _evenInfo: string,

        evenCauses: IEventCause[],

        consumedBy: number,

        createdAt: Date;
        updatedAt: Date;

        getObjId(): number;
        getDomaId(): number;
    }

    export class ObjectEventStatic implements IObjectEvent {

        _id: number;
        _evenType: number|cominfo.EEventType;
        _objId: number|cominfo.IObjectInfo;
        _domaId: number|cominfo.IDomainInfo;
        _evenCode: number;
        objState: number|cominfo.EObjectState;
        _occurredAt: Date;
        realtime: boolean;
        _placeName: string;
        evenLocation: cominfo.IEventLocation;
        _evenInfo: string;
        evenCauses: cominfo.IEventCause[];
        consumedBy: number;
        createdAt: Date;
        updatedAt: Date;

        constructor(eventId: number, evenType: number|EEventType, objectId: number|IObjectInfo, domainId: Base32String|number|IDomainInfo
            , eventCode: number, occurredAt: Date, placeName: string, eventInfo: string, objectState?: number|cominfo.EObjectState
            , realtime?: boolean, evenLocation?: IEventLocation, evenCauses?: IEventCause[]) {

            if (eventId != 0 && (eventId <= Math.round((evenType << 8) * Math.pow(2, 40)) || eventId >= Math.round(((evenType + 1) << 8) * Math.pow(2, 40)))) {
                eventId = -1;
            }
            this._id = eventId;
            this._evenType = evenType;
            this._objId = 0;
            if ((objectId instanceof Object)) {
                let type: EObjectInfoType = EObjectInfoType.IT_Unknow;
                switch (this._evenType) {
                    case EEventType.ET_Device:
                        type = EObjectInfoType.IT_Device;
                        break;
                    case EEventType.ET_Vehicle:
                        type = EObjectInfoType.IT_Vehicle;
                        break;
                }
                if (ObjectInfoStatic.isObjectInfo(<IObjectInfo>objectId, type)) this._objId = objectId;
            }
            else {
                switch (this._evenType) {
                    case EEventType.ET_Device:
                        this._objId = checkDeviId(<number>objectId);
                        break;
                    case EEventType.ET_Vehicle:
                        this._objId = checkVehiId(<number>objectId);
                        break;
                }
            }
            this._domaId = 0;
            if ((domainId instanceof Object)) {
                if (ObjectInfoStatic.isObjectInfo(<IDomainInfo>domainId, EObjectInfoType.IT_Domain)) this._domaId = <IDomainInfo>domainId;
            }
            else {
                this._domaId = checkDomaId(domainId);
            }
            this._evenCode = (eventCode > 0) ? eventCode : 0;
            this._occurredAt = (occurredAt instanceof Date) && occurredAt.getTime() > cominfo.ObjectBeginDate.getTime() ? occurredAt : cominfo.ObjectBeginDate;
            this._placeName = (placeName) ? placeName : '';
            this._evenInfo = (eventInfo) ? eventInfo : '';

            this.objState = (objectState) ? objectState : 0;
            this.realtime = (realtime) ? realtime : false;
            this.evenLocation = ((evenLocation instanceof Object) && (evenLocation._coordinate instanceof Array)) ? cloneObject(evenLocation, true) : null;
            this.evenCauses = (typeof evenCauses === 'array') ? cloneObject(evenCauses, true) : null;
            this.consumedBy = 0;
            this.createdAt = null;
            this.updatedAt = null;

            // Auto-id of Event id. from (EventType << 8 | (DomainId (15-bit) >> 7) & 0xFF) * 2^40 + getTime() from 2012-01-01, in millisec. (40-bit)
            if (this._id === 0) {
                this._id = ObjectEventStatic.generateEventId(this._evenType, this._domaId, this._occurredAt);
            }
        }

        getObjId(): number {

            let objId: number = (this._objId instanceof Object && (<cominfo.IObjectInfo>this._objId)._id)
                ? (<cominfo.IObjectInfo>this._objId)._id : <number>this._objId;
            return objId;
        }

        getDomaId(): number {

            let domaId: number = (this._domaId instanceof Object && (<cominfo.IDomainInfo>this._domaId)._id)
                ? (<cominfo.IDomainInfo>this._domaId)._id : <number>this._domaId;
            return domaId;
        }

        static generateEventId(evenType: number|EEventType, domainId: number|IDomainInfo, occurredAt: Date) : number {

            let domaId: number = (ObjectInfoStatic.isObjectInfo(<IDomainInfo>domainId, EObjectInfoType.IT_Domain)) ? (<IDomainInfo>domainId)._id : <number>domainId;

            if (evenType <= 0 || domaId <= 0 || occurredAt == null || occurredAt.getTime() <= cominfo.ObjectBeginDate.getTime()) return 0;

            let evenId: number = Math.round( (((evenType << 8) & 0xF00) | ((domaId >> 7) & 0x0FF)) * Math.pow(2, 40) );
            evenId = evenId + (occurredAt.getTime() - cominfo.ObjectBeginDate.getTime());
            return evenId;
        }
    }

    export enum ETrackDeviceEventCode {
        AA_SOS = 101000,    // '1'three dits form the letter S, and three dash make the letter O
        AB_DIN1 = 101100,   // digital input group 1 (4-bit): '0'off,'1'on
        AB_DIN1_Off = 101100,   // digital input group 1 (4-bit): '0'off,'1'on
        AB_DIN1_On = 101101,   // digital input group 1 (4-bit): '0'off,'1'on
        AC_DIN2 = 101200,   // digital input group 2 (4-bit): '0'off,'1'on
        AC_DIN2_Off = 101200,   // digital input group 2 (4-bit): '0'off,'1'on
        AC_DIN2_On = 101201,   // digital input group 2 (4-bit): '0'off,'1'on
        AD_AccPower = 101300,   // accessory power status: '0'off,'1'on
        AD_AccPower_Off = 101300,   // accessory power status: '0'off,'1'on
        AD_AccPower_On = 101301,   // accessory power status: '0'off,'1'on
        AE_ExtSupply = 101400,   // external power supply status: '0'disconnect,'1'connect
        AE_ExtSupply_Disc = 101400,   // external power supply status: '0'disconnect,'1'connect
        AE_ExtSupply_Conn = 101401,   // external power supply status: '0'disconnect,'1'connect
        AF_LowSupply = 101500,   // low power supply: '0'internal battery,'1'external supply
        AF_LowSupply_Int = 101500,   // low power supply: '0'internal battery,'1'external supply
        AF_LowSupply_Ext = 101501,   // low power supply: '0'internal battery,'1'external supply
        AG_TrackCon = 101600,   // tracking by conditions: '1'distance,'2'angular
        AG_TrackCon_Dist = 101601,   // tracking by conditions: '1'distance,'2'angular
        AG_TrackCon_Angular = 101602,   // tracking by conditions: '1'distance,'2'angular
        AH_Crash = 101700,   // hit/crash detection: '1'hit,'2'spin,'3'roll over
        AH_Crash_Hit = 101701,   // hit/crash detection: '1'hit,'2'spin,'3'roll over
        AI_InGeoFence = 101800,
        AJ_OutGeoFence = 101900,
        AK_GPSAnt = 102000,
        AK_GPSAnt_Cut = 10200,
        AL_GPSSignal = 102100,
        AL_GPSSignal_Lost = 102100,
        AL_GPSSignal_Gain = 102101,
        AM_Movement = 102200,
        AM_Movement_Stop = 102200,
        AM_Movement_Start = 102201,
        AN_Idle = 102300,
        AO_Speed = 102400,
        AO_Speed_Normal = 102400,
        AO_Speed_Over = 102400,
        AP_Photo = 102500,
        AP_Photo_Take = 102500,
        AQ_Fatigue = 102600,
        AR_AutoId = 102700,
        AS_Shift = 102800,
        AT_TrackInt = 102900,
        AT_TrackInt_Off = 102900,
        AT_TrackInt_On = 102901,
        AU_Driver = 103000,
        AV_Temp = 103100,
        AW_Accel = 103200,
        AX_Analog = 103300,
        AY_Reserved = 103400,
        AZ_TurnOn = 103500,
        AZ_TurnOn_Power = 103501
    }

    export interface IDeviceMoving {
        directionDeg: number,
        speedKmH: number,
        angleDeg: number,
        rpm: number,
    }

    export class DeviceMovingStatic implements IDeviceMoving{

        directionDeg: number;
        speedKmH: number;
        angleDeg: number;
        rpm: number;

        constructor(directionDeg?: number, speedKmH?: number, angleDeg?: number, rpm?: number) {

            this.directionDeg = (!isNaN(directionDeg) && directionDeg >= 0) ? directionDeg : -1;
            this.speedKmH = (!isNaN(speedKmH) && speedKmH >= 0) ? speedKmH : -1;
            this.angleDeg = (angleDeg) ? angleDeg : 0;
            this.rpm = (!isNaN(rpm) && rpm >= 0) ? rpm : -1;
        }
    }

    export interface IDeviceStats {
        mileage: number,
        batteryLevel: number,
        gnssLevel: number,
        cellLevel: number,
        // wifiLevel: number,
        // beaconLevel: number,
        // ipLevel: number,
    }

    export class DeviceStatsStatic implements IDeviceStats {

        mileage: number;
        batteryLevel: number;
        gnssLevel: number;
        cellLevel: number;
        // wifiLevel: number;
        // beaconLevel: number;
        // ipLevel: number;

        constructor(mileage?: number, batteryLevel?: number, gnssLevel?: number, cellLevel?: number) {

            this.mileage = (mileage) ? mileage : -1;
            this.batteryLevel = (batteryLevel) ? batteryLevel : -1;
            this.gnssLevel = (gnssLevel) ? gnssLevel : -1;
            this.cellLevel = (cellLevel) ? cellLevel : -1;
        }
    }

    export interface ITrackDeviceEvent extends IObjectEvent {

        // _id: number;
        // _evenType: number|cominfo.EEventType;
        //.. who ..
        // Override
        _objId: number|ITrackDeviceInfo;
        // _domaId: number|IDomainInfo;
        // IMEI, MAC
        _deviAddrNo: string,
        prodModel: number,
        // 19-bit represent in Crockford's Base32
        vehiId: number|IVehicleInfo,
        //.. what ..
        // Override
        _evenCode: number|ETrackDeviceEventCode,
        // objState: number|EobjectState,
        //.. when ..
        // _occurredAt: Date,
        // realtime: boolean,
        linkState: number|ELinkState,
        //.. where ..
        // _placeName: string,
        // evenLocation: IEventLocation,
        // Locateable time
        locatedAt: Date,
        areaLocations: IEventLocation[],
        //.. why ..
        // _evenInfo: string,
        // evenCauses: IEventCause[];
        // timestamps: Object
        _deviMoving: IDeviceMoving,
        deviDigitalIns: number[],
        deviDigitalOuts: number[],
        deviAnalogIns: number[],
        deviAnalogOuts: number[],
        deviSensors: IEventCause[],
        deviStats: IDeviceStats,

        getVehiId();
    }

    export function createTrackDeviceEvent(event: ITrackDeviceEvent): TrackDeviceEventStatic {

        let newEvent: TrackDeviceEventStatic = new TrackDeviceEventStatic(event._id, event._objId, event._domaId, event._deviAddrNo
                , event._evenCode, event._occurredAt, event._placeName, event._evenInfo, event._deviMoving, event.objState
                , event.realtime, event.evenLocation, event.evenCauses);
        if (!newEvent|| newEvent._id < 0) return null;
        assignObject(event,  newEvent);
        return newEvent;
    }

    export function toTrackDeviceEventString(event: ITrackDeviceEvent): string {

        let strs: string[] = [];

        strs.push(cominfo.encode20(cominfo.checkObjId(event._objId) - cominfo.EObjectIdCategory.IC_DeviceMin + 1));
        strs.push(',');
        (event._deviAddrNo) && strs.push(event._deviAddrNo);
        strs.push(',');
        (event.vehiId) && strs.push(cominfo.encode20(cominfo.checkVehiId(event.vehiId)));
        strs.push(',');
        strs.push(cominfo.ETrackDeviceEventCode[event._evenCode]);
        strs.push(',');
        strs.push(event._occurredAt.toLocaleString());
        strs.push(',');
        strs.push(cominfo.EObjectState[event.objState]);
        strs.push(',');
        strs.push(event.realtime ? 'R' : 'S');
        strs.push(',');
        (event.evenLocation && event.evenLocation.locaId) && strs.push(event.evenLocation.locaId.toString());
        strs.push(',[');
        if (event.evenLocation && event.evenLocation._coordinate) {
            (event.evenLocation._coordinate.length >= 2) && strs.push(event.evenLocation._coordinate[1].toString());
            strs.push(',');
            (event.evenLocation._coordinate.length >= 2) && strs.push(event.evenLocation._coordinate[0].toString());
            if (event.evenLocation._coordinate.length >= 3) {
                strs.push(',');
                strs.push(event.evenLocation._coordinate[2].toString());
            }
        }
        strs.push(']');

        strs.push(',');
        (event._deviMoving && event._deviMoving.speedKmH) && strs.push(event._deviMoving.speedKmH.toString() + 'kmh');
        strs.push(',');
        (event._deviMoving &&event._deviMoving.directionDeg) && strs.push(event._deviMoving.directionDeg.toString() + 'deg');
        strs.push(',');
        (event.deviStats && event.deviStats.batteryLevel) && strs.push(event.deviStats.batteryLevel.toString());
        strs.push(';');

        return strs.join('');
    }

    export class TrackDeviceEventStatic extends ObjectEventStatic implements ITrackDeviceEvent {

        _objId: number|ITrackDeviceInfo;
        _deviAddrNo: string;
        prodModel: number;
        vehiId: number|IVehicleInfo;
        _evenCode: number|ETrackDeviceEventCode;
        linkState: number|ELinkState;
        locatedAt: Date;
        areaLocations: IEventLocation[];
        _deviMoving: IDeviceMoving;
        deviDigitalIns: number[];
        deviDigitalOuts: number[];
        deviAnalogIns: number[];
        deviAnalogOuts: number[];
        deviSensors: IEventCause[];
        deviStats: IDeviceStats;

        constructor(eventId: number, deviceId: number|ITrackDeviceInfo, domainId: Base32String|number|IDomainInfo, deviceAddrNo: string
                , eventCode: number, occurredAt: Date, placeName: string, eventInfo: string, deviceMoving: IDeviceMoving
                , objectState?: number|cominfo.EObjectState, realtime?: boolean, evenLocation?: IEventLocation, evenCauses?: IEventCause[]) {

            super(eventId, EEventType.ET_Device, deviceId, domainId, eventCode, occurredAt, placeName, eventInfo, objectState, realtime, evenLocation, evenCauses);

            this._deviAddrNo = deviceAddrNo;
            this._deviMoving = ((deviceMoving instanceof Object)) ? cloneObject(deviceMoving, true) : new DeviceMovingStatic();

            this.prodModel = 0;
            this.vehiId = 0;
            this.linkState = 0;
            //this.locatedAt = cominfo.ObjectBeginDate;
            this.locatedAt = null;
            this.areaLocations = null;
            this.deviDigitalIns = null;
            this.deviDigitalOuts = null;
            this.deviAnalogIns = null;
            this.deviAnalogOuts = null;
            this.deviSensors = null;
            this.deviStats = null;
        }

        getVehiId(): number {
            let vehiId: number = ((this.vehiId instanceof Object) && (<cominfo.IVehicleInfo>this.vehiId)._id)
                ? (<cominfo.IVehicleInfo>this.vehiId)._id : <number>this.vehiId;
            return vehiId;
        }

    }

    export enum ETrackVehicleEventCode {

        BA_State = 111000,

        BB_Request = 111100,
        BB_Request_SOS = 111101,
            // begin/end call

        BC_Track = 111200,
        BC_Track_Interval_Off = 111200,
        BC_Track_Interval_On = 111201,
        BC_Track_Angle_On = 111203,
        BC_Track_Distance_On = 111205,

        BD_Link = 111300,
        BD_Link_GNSS_Lost = 111300,
        BD_Link_GNSS_Gain = 111301,
        BD_Link_Cell_Lost = 111310,
        BD_Link_Cell_Gain = 111311,
        BD_Link_Wifi_Lost = 111320,
        BD_Link_Wifi_Gain = 111321,
        BD_Link_Beacon_Lost = 111330,
        BD_Link_Beacon_Gain = 111331,
        BD_Link_IP_Lost = 111340,
        BD_Link_IP_Gain = 111341,

        BE_Locate = 111400,
        BE_Locate_Lost = 111400,
        BE_Locate_Okay = 111401,

        BF_Drive = 111500,
        BF_Drive_OverSpeed = 111501,
        BF_Drive_OverAccel = 111503,
        BF_Drive_UnderAccel = 111504,
        BF_Drive_OverRPM = 111505,

        BG_Elect = 111600,
        BG_Elect_PriSuppLost = 111602,
        BG_Elect_PriSuppLow = 111603,

        BH_Fuel = 111700,
        BH_Fuel_PriPetrolLost = 111702,
        BH_Fuel_PriPetrolFill = 111703,

        BI_Trig = 111800,
        BI_Trig_Driving0_Off = 111800,
        BI_Trig_Driving0_On = 111801,
        BI_Trig_Passenger0_Off = 111810,
        BI_Trig_Passenger0_On = 111811,
        BI_Trig_Cargo0_Off = 111820,
        BI_Trig_Cargo0_On = 111821,
        BI_Trig_External0_Off = 111820,
        BI_Trig_External0_On = 111821,

        BJ_Switch = 111900,
        BJ_Switch_Driving0_Off = 111900,
        BJ_Switch_Driving0_On = 111901,

        BK_Temp = 112000,
        BK_Temp_Driving0_Okay = 112000,
        BK_Temp_Driving0_Over = 112001,

        BL_Weather = 112100,

        BM_Surveil = 112200,

        BO_Photo = 112400,

        BP_Id = 112500,

        BZ_Device = 113500,
        BZ_Device_Reboot = 113500,
        BZ_Device_PowerOn = 113501,
    }

    export const enum ELinkState {
        LINK_Down,
        LINK_Up,
        LINK_Noise
    }


    // export interface IAddressInfo {
    //     _country: string
    //     _postcode: number,
    //     _province: string,
    //     _city: string,
    //     subcity: string,
    //     street: string,
    //     alley: string,
    //     _premise: string,
    //     building: string,
    //     floor: string,
    //     room: string,
    // }

    export interface IVehicleDriving extends IDeviceMoving{

        fatigueHour: number
    }

    export class VehicleDrivingStatic extends DeviceMovingStatic implements IVehicleDriving {


        fatigueHour: number;

        constructor(movingDirection?: IDeviceMoving, fatigueSpeed?: number)
        constructor(movingDirection?: any, fatigueSpeed?: number, angleDeg?: number, rpm?: number, fatigueHour?: number) {

            if ((movingDirection instanceof Object)) {
                super((<IDeviceMoving>movingDirection).directionDeg, (<IDeviceMoving>movingDirection).speedKmH
                       , (<IDeviceMoving>movingDirection).angleDeg, (<IDeviceMoving>movingDirection).rpm);
                this.fatigueHour = (!isNaN(fatigueSpeed) && fatigueSpeed >= 0) ? fatigueSpeed : -1;
            }
            else {
                super(<number>movingDirection, fatigueSpeed, angleDeg, rpm);
                this.fatigueHour = (!isNaN(fatigueHour) && fatigueHour >= 0) ? fatigueHour : -1;
            }
        }
    }

    export interface IVehicleValueAny {
        Driving: any[],
        Passenger: any[],
        Cargo: any[],
        External: any[]
    }

    export class VehicleValueAnyStatic implements IVehicleValueAny {

        Driving: any[];
        Passenger: any[];
        Cargo: any[];
        External: any[];

        constructor(Driving?: any[], Passenger?: any[], Cargo?: any[], External?: any[]) {

            if (Driving instanceof Array) this.Driving = Driving;
            if (Passenger instanceof Array) this.Passenger = Passenger;
            if (Cargo instanceof Array) this.Cargo = Cargo;
            if (External instanceof Array) this.Driving = External;
        }
    }

    export interface IVehicleValueBooleans extends IVehicleValueAny {

        Driving: boolean[],
        Passenger: boolean[],
        Cargo: boolean[],
        External: boolean[],
    }

    export class VehicleValueBooleansStatic extends  VehicleValueAnyStatic implements IVehicleValueBooleans {

    }

    export interface IVehicleValueNumbers extends IVehicleValueAny {

        Driving: number[],
        Passenger: number[],
        Cargo: number[],
        External: number[],
    }

    export class VehicleValueNumbersStatic extends  VehicleValueAnyStatic implements IVehicleValueNumbers {

    }

    export interface IVehicleValueStrings extends IVehicleValueAny {
        Driving: string[],
        Passenger: string[],
        Cargo: string[],
        External: string[],
    }

    export class VehicleValueStringsStatic extends  VehicleValueAnyStatic implements IVehicleValueStrings {

    }

    export interface IVehicleStats {
        mileage: number,
        avgSpeedkmh: number,
        avgFuelConskmL: number,
    }

    export interface ITrackVehicleEvent extends IObjectEvent {
        // _id: number;
        // _evenType: number|cominfo.EEventType;
        //.. who ..
        // Override
        _objId: number|IVehicleInfo;
        // _domaId: number|IDomainInfo;
        _deviIds: number[]|ITrackDeviceInfo[],
        drivId: number,
        vehiName: string,
        //.. what ..
        // Override
        _evenCode: number|ETrackVehicleEventCode,
        // objState: number|EobjectState,
        deviEventId: number|ITrackDeviceEvent;
        //.. when ..
        // _occurredAt: Date,
        // realtime: boolean,
        linkState: number|ELinkState,
        //.. where ..
        // _placeName: string,
        // evenLocation: IEventLocation,
        locatedAt: Date;
        tripId: number,
        address: IAddressInfo,
        //.. why ..
        // _evenInfo: string,
        // evenCauses: IEventCause[];
        // createdAt: Date;
        // updatedAt: Date;
        // direction, speed, track angle, force/acceleration, rpm, fatigue hour
        vehiDriving: IVehicleDriving
        // pri./sec. supplies, pri./sec. Cargo
        vehiElectrics: IVehicleValueNumbers,
        // pri./sec. petrol,
        vehiFuels: IVehicleValueNumbers,
        // turn-on engine, doors: main, front/rear, pri./sec. passengers, pri./sec. Cargo
        vehiTrigs: IVehicleValueBooleans,
        // disable engine, locks: front/rear, pri./sec. Cargo, pri./sec. alarm
        vehiSwitches: IVehicleValueBooleans,
        // engine, positions: main, front/rear, pri./sec. passengers, pri./sec. Cargo
        vehiTemperatures: IVehicleValueNumbers,
        // engine, positions: main, front/rear, pri./sec. passengers, pri./sec. Cargo
        vehiPhotos: IVehicleValueStrings,
        // accept/reject license, driver id. card, job id.
        deviIdentifies: IVehicleValueStrings,
        // sets of humidity, oxygen, co
        //vehiWeathers: vehiWeathers,
        // mileage, avg. speed, pri./sec. fuel cons.,
        vehiStats: IVehicleStats,
        
        getDeviId(index: number): number;
    }

    export function createTrackVehicleEvent(event: ITrackVehicleEvent): TrackVehicleEventStatic {

        let newEvent: TrackVehicleEventStatic = new TrackVehicleEventStatic(event._id, event._objId, event._domaId, event._evenCode
                , event._occurredAt, event._placeName, event._evenInfo, event._deviIds, event.vehiDriving, event.deviEventId
                , event.objState, event.realtime, event.evenLocation, event.evenCauses);
        if (!newEvent|| newEvent._id < 0) return null;
        assignObject(event,  newEvent);
        return newEvent;
    }

    export function setVehicleValue(obj: Object, path: string, value: any): string {

        let subject: string = null;
        let parts: string[] = path.split('.');
        let index: number = 0;
        let current: Object = obj;
        if (parts.length - index === 3) {
            let field: string = parts[index++];
            if (!(current instanceof Object)) current[field] = {};
            current = current[field];
        }
        if (parts.length - index === 2) {
            let field: string = parts[index++];
            if (!(current instanceof Object)) current[field] = {};
            current = current[field];
            subject = field;
        }
        let field: string = parts[index++];
        if (!(current instanceof Array)) current = [];
        current[field] = value;

        return subject;
    }

    export function getVehicleEventCode(deviceEventCode: ETrackDeviceEventCode|number, deviceMapping: Object): ETrackVehicleEventCode|number {

        let code: ETrackVehicleEventCode|number = 0;

        switch (deviceEventCode) {
            case ETrackDeviceEventCode.AA_SOS:
                code = ETrackVehicleEventCode.BB_Request_SOS;
                break;
            case ETrackDeviceEventCode.AB_DIN1:
            case ETrackDeviceEventCode.AB_DIN1_Off:
                if (deviceMapping && typeof deviceMapping['DIN1'] === 'string') {
                    let parts: string[] = deviceMapping['DIN1'].split('.');
                    if (parts.length === 3 && parts[0] === 'vehiTrigs') {
                        code = ETrackVehicleEventCode['BI_Trig_' + parts[1] + parts[2] + '_Off'];
                    }
                }
                else {
                    code = ETrackVehicleEventCode.BI_Trig_Passenger0_Off;
                }
                break;
            case ETrackDeviceEventCode.AB_DIN1_On:
                if (deviceMapping && typeof deviceMapping['DIN1'] === 'string') {
                    let parts: string[] = deviceMapping['DIN1'].split('.');
                    if (parts.length === 3 && parts[0] === 'vehiTrigs') {
                        code = ETrackVehicleEventCode['BI_Trig_' + parts[1] + parts[2] + '_On'];
                    }
                }
                else {
                    code = ETrackVehicleEventCode.BI_Trig_Passenger0_On;
                }
                break;
            case ETrackDeviceEventCode.AC_DIN2:
            case ETrackDeviceEventCode.AC_DIN2_Off:
                if (deviceMapping && typeof deviceMapping['DIN2'] === 'string') {
                    let parts: string[] = deviceMapping['DIN2'].split('.');
                    if (parts.length === 3 && parts[0] === 'vehiTrigs') {
                        code = ETrackVehicleEventCode['BI_Trig_' + parts[1] + parts[2] + '_Off'];
                    }
                }
                else {
                    code = ETrackVehicleEventCode.BI_Trig_Cargo0_Off;
                }
                break;
            case ETrackDeviceEventCode.AC_DIN2_On:
                if (deviceMapping && typeof deviceMapping['DIN2'] === 'string') {
                    let parts: string[] = deviceMapping['DIN2'].split('.');
                    if (parts.length === 3 && parts[0] === 'vehiTrigs') {
                        code = ETrackVehicleEventCode['BI_Trig_' + parts[1] + parts[2] + '_On'];
                    }
                }
                else {
                    code = ETrackVehicleEventCode.BI_Trig_Cargo0_On;
                }                break;
            case ETrackDeviceEventCode.AD_AccPower:
            case ETrackDeviceEventCode.AD_AccPower_Off:
                code = ETrackVehicleEventCode.BI_Trig_Driving0_Off;
                break;
            case ETrackDeviceEventCode.AD_AccPower_On:
                code = ETrackVehicleEventCode.BI_Trig_Driving0_On;
                break;
            case ETrackDeviceEventCode.AE_ExtSupply:
            case ETrackDeviceEventCode.AE_ExtSupply_Disc:
            case ETrackDeviceEventCode.AE_ExtSupply_Conn:
            case ETrackDeviceEventCode.AF_LowSupply:
            case ETrackDeviceEventCode.AF_LowSupply_Int:
            case ETrackDeviceEventCode.AF_LowSupply_Ext:
            case ETrackDeviceEventCode.AG_TrackCon:
            case ETrackDeviceEventCode.AG_TrackCon_Dist:
                code = ETrackVehicleEventCode.BC_Track_Distance_On;
                break;
            case ETrackDeviceEventCode.AG_TrackCon_Angular:
                code = ETrackVehicleEventCode.BC_Track_Angle_On;
                break;
            case ETrackDeviceEventCode.AH_Crash:
            case ETrackDeviceEventCode.AH_Crash_Hit:
            case ETrackDeviceEventCode.AI_InGeoFence:
            case ETrackDeviceEventCode.AJ_OutGeoFence:
            case ETrackDeviceEventCode.AK_GPSAnt:
            case ETrackDeviceEventCode.AK_GPSAnt_Cut:
            case ETrackDeviceEventCode.AL_GPSSignal:
            case ETrackDeviceEventCode.AL_GPSSignal_Lost:
                code = ETrackVehicleEventCode.BD_Link_GNSS_Lost;
                break;
            case ETrackDeviceEventCode.AL_GPSSignal_Gain:
                code = ETrackVehicleEventCode.BD_Link_GNSS_Gain;
                break;
            case ETrackDeviceEventCode.AM_Movement:
            case ETrackDeviceEventCode.AM_Movement_Stop:
            case ETrackDeviceEventCode.AM_Movement_Start:
            case ETrackDeviceEventCode.AN_Idle:
            case ETrackDeviceEventCode.AO_Speed:
            case ETrackDeviceEventCode.AO_Speed_Normal:
            case ETrackDeviceEventCode.AO_Speed_Over:
            case ETrackDeviceEventCode.AP_Photo:
            case ETrackDeviceEventCode.AP_Photo_Take:
            case ETrackDeviceEventCode.AQ_Fatigue:
            case ETrackDeviceEventCode.AR_AutoId:
            case ETrackDeviceEventCode.AS_Shift:
            case ETrackDeviceEventCode.AT_TrackInt:
            case ETrackDeviceEventCode.AT_TrackInt_Off:
                code = ETrackVehicleEventCode.BC_Track_Interval_Off;
                break;
            case ETrackDeviceEventCode.AT_TrackInt_On:
                code = ETrackVehicleEventCode.BC_Track_Interval_On;
                break;
            case ETrackDeviceEventCode.AU_Driver:
            case ETrackDeviceEventCode.AV_Temp:
            case ETrackDeviceEventCode.AW_Accel:
            case ETrackDeviceEventCode.AX_Analog:
            case ETrackDeviceEventCode.AY_Reserved:
            case ETrackDeviceEventCode.AZ_TurnOn:
            case ETrackDeviceEventCode.AZ_TurnOn_Power:
                break;
        }

        //( isDebug && this.debug && this.debug('ERR:' + error.message + ':' + error.stack) );
        return code;
    }

    export function createTrackVehicleEventByDevice(vehicle: IVehicleInfo, event: ITrackDeviceEvent): TrackVehicleEventStatic {

        let deviMapping: Object = (vehicle.vehiConfigs instanceof Object) ? (<any>vehicle.vehiConfigs).deviMapping : null;
        let newEvent: TrackVehicleEventStatic = new TrackVehicleEventStatic(0, vehicle._id, event._domaId
            , getVehicleEventCode(event._evenCode, deviMapping)
            , event._occurredAt, event._placeName, event._evenInfo, [<number>event._objId], new VehicleDrivingStatic(event._deviMoving), event._id
            , event.objState, event.realtime, event.evenLocation, event.evenCauses);
        if (!newEvent|| newEvent._id < 0) return null;
        //TODO Assign some device event to vehicle event
        //Combine area to event location

        if ((newEvent.evenLocation instanceof Object) && (event.areaLocations instanceof Array) && event.areaLocations.length) {
            event.areaLocations.forEach((location: IEventLocation, index: number) => {
                if (!(newEvent.evenLocation._coordinate instanceof Array) && (location._coordinate instanceof Array)) {
                    newEvent.evenLocation = cloneObject(location, true);
                }
                if (location.locaId > 0) {
                    newEvent.evenLocation.locaId = location.locaId;
                    newEvent.evenLocation.locaNames = cloneObject(location.locaNames, true);
                }
            });
        }

        // Electrics
        if (!(newEvent.vehiElectrics instanceof Object)) newEvent.vehiElectrics = new VehicleValueNumbersStatic([]);

        if ((newEvent.vehiElectrics.Driving instanceof Array)) {
            let drivingPower: number = (event.deviAnalogIns && event.deviAnalogIns.length >= 3) ? event.deviAnalogIns[2] : -2147483648;
            if (newEvent.vehiElectrics.Driving.length < 1) {
                newEvent.vehiElectrics.Driving.push(drivingPower);
            }
            else {
                newEvent.vehiElectrics.Driving[0] = drivingPower;
            }
            let drivingBatt: number = (event.deviStats && event.deviStats.batteryLevel) ? event.deviStats.batteryLevel : -1;
            if (newEvent.vehiElectrics.Driving.length < 2) {
                newEvent.vehiElectrics.Driving.push(drivingBatt);
            }
            else {
                newEvent.vehiElectrics.Driving[1] = drivingBatt;
            }
        }
        return newEvent;
    }


    export function toTrackVehicleEventString(event: ITrackVehicleEvent): string {

        let strs: string[] = [];

        strs.push(cominfo.encode20(cominfo.checkObjId(event._objId)));
        strs.push(',[');
        for (let i: number = 0; i < ((event._deviIds instanceof Array) && event._deviIds.length); i++) {
            strs.push(cominfo.encode25(cominfo.checkDeviId(event._deviIds[i]) - cominfo.EObjectIdCategory.IC_DeviceMin + 1));
        }
        strs.push('],');
        strs.push(cominfo.ETrackVehicleEventCode[event._evenCode]);
        strs.push(',');
        strs.push(event._occurredAt.toLocaleString());
        strs.push(',');
        strs.push(cominfo.EObjectState[event.objState]);
        strs.push(',');
        strs.push(event.realtime ? 'R' : 'S');
        strs.push(',');
        (event.evenLocation && event.evenLocation.locaId) && strs.push(event.evenLocation.locaId.toString());
        strs.push(',[');
        if (event.evenLocation && event.evenLocation._coordinate) {
            (event.evenLocation._coordinate.length >= 2) && strs.push(event.evenLocation._coordinate[1].toString());
            strs.push(',');
            (event.evenLocation._coordinate.length >= 2) && strs.push(event.evenLocation._coordinate[0].toString());
            if (event.evenLocation._coordinate.length >= 3) {
                strs.push(',');
                strs.push(event.evenLocation._coordinate[2].toString());
            }
        }
        strs.push(']');

        strs.push(',');
        (event.vehiDriving && event.vehiDriving.speedKmH) && strs.push(event.vehiDriving.speedKmH.toString() + 'kmh');
        strs.push(',');
        (event.vehiDriving && event.vehiDriving.directionDeg) && strs.push(event.vehiDriving.directionDeg.toString() + 'deg');
        strs.push(',');
        (event.vehiStats && event.vehiStats.mileage) && strs.push(event.vehiStats.mileage.toString());
        strs.push(';');

        return strs.join('');
    }

    export class TrackVehicleEventStatic extends ObjectEventStatic implements ITrackVehicleEvent {

        _objId: number|IVehicleInfo;
        _deviIds: number[]|ITrackDeviceInfo[];
        drivId: number;
        vehiName: string;
        deviEventId: number|ITrackDeviceEvent;
        linkState: number|ELinkState;
        locatedAt: Date;
        tripId: number;
        address: IAddressInfo;
        vehiDriving: IVehicleDriving;
        vehiElectrics: IVehicleValueNumbers;
        vehiFuels: IVehicleValueNumbers;
        vehiTrigs: IVehicleValueBooleans;
        vehiSwitches: IVehicleValueBooleans;
        vehiTemperatures: IVehicleValueNumbers;
        vehiPhotos: IVehicleValueStrings;
        deviIdentifies: IVehicleValueStrings;
        vehiStats: IVehicleStats;

        constructor(eventId: number, vehicleId: number|IVehicleInfo, domainId: Base32String|number|IDomainInfo, eventCode: number
                , occurredAt: Date, placeName: string, eventInfo: string, deviceIds: number[]|ITrackDeviceInfo[], vehicleDriving: IVehicleDriving
                , deviceEventId: number|ITrackDeviceEvent, objectState?: number|cominfo.EObjectState, realtime?: boolean, evenLocation?: IEventLocation
                , evenCauses?: IEventCause[]) {

            super(eventId, EEventType.ET_Vehicle, vehicleId, domainId, eventCode, occurredAt, placeName, eventInfo, objectState, realtime, evenLocation, evenCauses);

            if (deviceIds && deviceIds.length) {
                this._deviIds = cominfo.cloneObject(deviceIds);
            }
            this.vehiDriving = ((vehicleDriving instanceof Object)) ? vehicleDriving : new VehicleDrivingStatic();
            this.deviEventId = (deviceEventId) ? deviceEventId : 0;

            this.drivId = 0;
            this.vehiName = null;
            this.linkState = ((this.deviEventId instanceof Object) && (<ITrackDeviceEvent>this.deviEventId).linkState) ? (<ITrackDeviceEvent>this.deviEventId).linkState : 0;
            this.locatedAt = ((this.deviEventId instanceof Object) && (<ITrackDeviceEvent>this.deviEventId).locatedAt) ? (<ITrackDeviceEvent>this.deviEventId).locatedAt : null;
            this.tripId = 0;
            this.address = null;
            this.vehiElectrics = null;
            this.vehiFuels = null;
            this.vehiTrigs = null;
            this.vehiSwitches = null;
            this.vehiTemperatures = null;
            this.vehiPhotos = null;
            this.deviIdentifies = null;
            this.vehiStats = null;
        }
        
        getDeviId(index:number): number {
            if (!(this._deviIds instanceof Array)) return -1;
            let deviId: number = (this._deviIds[index] instanceof Object && (<cominfo.ITrackDeviceInfo>this._deviIds[index])._id)
            ? (<cominfo.ITrackDeviceInfo>this._deviIds[index])._id : <number>this._deviIds[index];
            return deviId;
        }
    }

}